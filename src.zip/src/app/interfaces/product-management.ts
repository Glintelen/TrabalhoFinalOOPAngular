export interface ProductManagement {
    id?: string;
    name: string;
    descricao: string;
    categoria: string;
    preco: number;
    quantidade: number;
}
